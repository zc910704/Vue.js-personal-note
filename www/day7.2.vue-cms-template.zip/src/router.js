import VueRouter from 'vue-router'

var router = new VueRouter({
    routes: [

    ]
})

export default router